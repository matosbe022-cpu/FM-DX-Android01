package br.com.fmdx.android

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val defaultDirectory = "https://SEU-DIRETORIO.example/api"
    private val prefs by lazy { getSharedPreferences("fmdx", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var web: WebView? = null
    private var publicRows = JSONArray()
    private val bg = Color.rgb(8, 21, 34)
    private val panel = Color.rgb(19, 43, 64)
    private val cyan = Color.rgb(53, 182, 232)
    private val white = Color.WHITE
    private val muted = Color.rgb(158, 184, 204)

    private val directoryApi: String
        get() = prefs.getString("directory_api", defaultDirectory) ?: defaultDirectory

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 16)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 25f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        })
        status = TextView(this).apply {
            text = "FM-DX • Rádio definida por software"; textSize = 13f
            setTextColor(muted); setPadding(0, 5, 0, 16)
        }
        root.addView(status)
        return root
    }

    private fun scroll(content: LinearLayout) {
        val scroller = ScrollView(this).apply { isFillViewport = true; addView(content) }
        setContentView(scroller)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(panel)
        setOnClickListener { action() }
    }

    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); setHintTextColor(muted); setTextColor(white)
        textSize = 15f; setSingleLine(true); setPadding(14, 8, 14, 8)
        backgroundTintList = android.content.res.ColorStateList.valueOf(cyan)
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text; setTextColor(cyan); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 16, 0, 7)
    }

    private fun showHome() {
        web = null
        val content = base("FM-DX Android")
        content.addView(TextView(this).apply {
            text = "Sua rede de receptores FM-DX"; setTextColor(white); textSize = 17f
        })
        content.addView(TextView(this).apply {
            text = "Conecte-se a servidores públicos ou adicione um endereço privado compartilhado pelo proprietário."
            setTextColor(muted); textSize = 13f; setPadding(0, 5, 0, 14)
        })
        val address = field("Endereço do servidor (https://...)")
        content.addView(address, matchWrap())
        content.addView(button("CONECTAR") {
            normalize(address.text.toString())?.let { openServer(it) } ?: toast("Digite um endereço http:// ou https:// válido")
        }, matchWrap())
        content.addView(button("SALVAR ENDEREÇO / CONVITE") {
            normalize(address.text.toString())?.let { saveServer(it); toast("Servidor salvo nos seus favoritos") }
                ?: toast("Informe um endereço válido")
        }, matchWrap())
        content.addView(button("PROCURAR SERVIDORES PÚBLICOS") { loadDirectory() }, matchWrap())
        content.addView(button("CADASTRAR MEU SERVIDOR") { showRegisterServer() }, matchWrap())
        content.addView(button("MEUS SERVIDORES E CONVITES") { showSaved() }, matchWrap())
        content.addView(button("CONFIGURAÇÕES DO DIRETÓRIO") { showSettings() }, matchWrap())
        content.addView(label("COMO FUNCIONA"))
        content.addView(TextView(this).apply {
            text = "O servidor FM-DX e o receptor compatível continuam funcionando no computador do proprietário. Este aplicativo conecta os ouvintes ao servidor pela internet ou rede local."
            setTextColor(muted); textSize = 13f
        })
        scroll(content)
    }

    private fun loadDirectory() {
        if (directoryApi.contains("SEU-DIRETORIO")) { toast("Configure o endereço do diretório primeiro"); showSettings(); return }
        showDirectoryLoading()
        thread {
            try {
                val endpoint = directoryApi.trimEnd('/') + "/servers"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: "[]"
                conn.disconnect()
                if (code !in 200..299) throw Exception("Diretório respondeu HTTP $code")
                publicRows = JSONArray(body)
                runOnUiThread { showDirectoryResults("") }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Falha ao consultar o diretório"; toast(e.message ?: "Erro de conexão") }
            }
        }
    }

    private fun showDirectoryLoading() {
        val content = base("Servidores públicos")
        content.addView(TextView(this).apply { text = "Consultando diretório..."; setTextColor(muted) })
        content.addView(button("VOLTAR") { showHome() }, matchWrap())
        scroll(content)
    }

    private fun showDirectoryResults(filter: String) {
        val content = base("Servidores públicos")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        val search = field("Pesquisar por nome, cidade ou país", filter)
        content.addView(search, matchWrap())
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun render(term: String) {
            results.removeAllViews()
            var count = 0
            for (i in 0 until publicRows.length()) {
                val item = publicRows.optJSONObject(i) ?: continue
                val name = item.optString("name", "Servidor FM-DX")
                val city = item.optString("city")
                val country = item.optString("country")
                val description = item.optString("description")
                val searchable = "$name $city $country $description".lowercase()
                if (term.isNotBlank() && !searchable.contains(term.lowercase())) continue
                count++
                val url = item.optString("url")
                val details = listOf(city, country).filter { it.isNotBlank() }.joinToString(" • ")
                results.addView(label(name))
                if (details.isNotBlank()) results.addView(TextView(this).apply { text = details; setTextColor(muted); textSize = 12f })
                if (description.isNotBlank()) results.addView(TextView(this).apply { text = description; setTextColor(muted); textSize = 12f })
                results.addView(button("CONECTAR") { normalize(url)?.let { openServer(it) } ?: toast("Endereço inválido") }, matchWrap())
                results.addView(button("SALVAR NOS FAVORITOS") { normalize(url)?.let { saveServer(it); toast("Servidor salvo") } }, matchWrap())
            }
            if (count == 0) results.addView(TextView(this).apply {
                text = if (publicRows.length() == 0) "Nenhum servidor público cadastrado." else "Nenhum servidor corresponde à pesquisa."
                setTextColor(muted); setPadding(0, 18, 0, 18)
            })
            status.text = "$count servidor(es) encontrado(s)"
        }
        search.addTextChangedListener(SimpleWatcher { render(it) })
        render(filter)
        content.addView(button("ATUALIZAR LISTA") { loadDirectory() }, matchWrap())
        scroll(content)
    }

    private fun showSaved() {
        val content = base("Meus servidores")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        val arr = JSONArray(prefs.getString("servers", "[]"))
        if (arr.length() == 0) content.addView(TextView(this).apply {
            text = "Nenhum endereço salvo. Você pode adicionar servidores privados na tela inicial."
            setTextColor(muted); setPadding(0, 18, 0, 18)
        })
        for (i in 0 until arr.length()) {
            val address = arr.optString(i)
            content.addView(label(address))
            content.addView(button("CONECTAR") { openServer(address) }, matchWrap())
            content.addView(button("REMOVER DOS FAVORITOS") { removeServer(address); showSaved() }, matchWrap())
        }
        scroll(content)
    }

    private fun showSettings() {
        val content = base("Configurações")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        content.addView(label("ENDEREÇO DO DIRETÓRIO PÚBLICO"))
        val api = field("https://seu-dominio.com/api", directoryApi)
        content.addView(api, matchWrap())
        content.addView(button("SALVAR CONFIGURAÇÃO") {
            val value = api.text.toString().trim().trimEnd('/')
            if (!value.startsWith("https://")) toast("Para o diretório público, use um endereço HTTPS seguro")
            else { prefs.edit().putString("directory_api", value).apply(); toast("Endereço do diretório salvo"); showHome() }
        }, matchWrap())
        content.addView(TextView(this).apply {
            text = "O diretório público precisa estar publicado em um servidor HTTPS. Servidores privados podem ser adicionados diretamente pelo endereço ou convite, sem aparecer na lista pública."
            setTextColor(muted); textSize = 13f; setPadding(0, 16, 0, 0)
        })
        scroll(content)
    }


    private fun showRegisterServer() {
        val content = base("Cadastrar servidor")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        content.addView(TextView(this).apply {
            text = "Publique seu FM-DX no diretório compartilhado. O servidor FM-DX precisa estar acessível pela internet usando HTTPS."
            setTextColor(muted); textSize = 13f
        })
        val name = field("Nome da estação")
        val serverUrl = field("URL pública do FM-DX (https://...)")
        val city = field("Cidade")
        val country = field("País", "Brasil")
        val description = field("Descrição (opcional)")
        val token = field("Token administrativo do diretório", prefs.getString("directory_admin_token", "") ?: "")
        val visibility = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Público — aparece na busca", "Privado — não aparece na busca"))
        }
        listOf(name, serverUrl, city, country, description, token).forEach { content.addView(it, matchWrap()) }
        content.addView(label("VISIBILIDADE")); content.addView(visibility, matchWrap())
        content.addView(button("PUBLICAR CADASTRO") {
            val n = name.text.toString().trim()
            val u = normalize(serverUrl.text.toString())
            val t = token.text.toString().trim()
            if (n.isBlank() || u == null || t.isBlank()) {
                toast("Informe nome, URL válida e token administrativo")
                return@button
            }
            if (!u.startsWith("https://")) {
                toast("Para publicar na internet, use HTTPS")
                return@button
            }
            val cityValue = city.text.toString().trim()
            val countryValue = country.text.toString().trim()
            val descriptionValue = description.text.toString().trim()
            val visibilityValue = if (visibility.selectedItemPosition == 0) "public" else "private"
            prefs.edit().putString("directory_admin_token", t).apply()
            status.text = "Enviando cadastro..."
            thread {
                try {
                    val endpoint = directoryApi.trimEnd('/') + "/servers"
                    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 10000; readTimeout = 10000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Authorization", "Bearer $t")
                    }
                    val payload = JSONObject().apply {
                        put("name", n); put("url", u); put("city", cityValue)
                        put("country", countryValue); put("description", descriptionValue)
                        put("visibility", visibilityValue)
                    }.toString()
                    conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val response = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    conn.disconnect()
                    if (code !in 200..299) throw Exception("HTTP $code: $response")
                    runOnUiThread { toast("Servidor cadastrado com sucesso!"); showHome() }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Falha no cadastro"; toast(e.message ?: "Erro ao publicar servidor") }
                }
            }
        }, matchWrap())
        content.addView(TextView(this).apply {
            text = "O token é guardado somente neste aparelho. Não compartilhe esse código. Para remover ou atualizar o cadastro, use o mesmo token administrativo."
            setTextColor(muted); textSize = 12f; setPadding(0, 12, 0, 0)
        })
        scroll(content)
    }

    private fun saveServer(address: String) {
        val old = JSONArray(prefs.getString("servers", "[]")); val next = JSONArray()
        for (i in 0 until old.length()) if (old.optString(i) != address) next.put(old.optString(i))
        next.put(address); prefs.edit().putString("servers", next.toString()).apply()
    }

    private fun removeServer(address: String) {
        val old = JSONArray(prefs.getString("servers", "[]")); val next = JSONArray()
        for (i in 0 until old.length()) if (old.optString(i) != address) next.put(old.optString(i))
        prefs.edit().putString("servers", next.toString()).apply()
    }

    private fun openServer(address: String) {
        val view = WebView(this); web = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.settings.allowFileAccess = false
        view.settings.allowContentAccess = false
        view.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        view.settings.safeBrowsingEnabled = true
        view.webChromeClient = WebChromeClient()
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return true
                return target.scheme != "https" && target.scheme != "http"
            }
            override fun onPageFinished(v: WebView?, url: String?) { status.text = "Servidor: ${url ?: address}" }
            override fun onReceivedError(v: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) toast("Não foi possível carregar o servidor. Verifique o endereço e a conexão.")
            }
        }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        shell.addView(button("← VOLTAR À LISTA") { view.stopLoading(); showHome() }, matchWrap())
        shell.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(shell)
        view.loadUrl(address)
    }

    private fun normalize(raw: String): String? {
        val value = raw.trim().trimEnd('/')
        if (!value.startsWith("https://") && !value.startsWith("http://")) return null
        return try { val u = URL(value); if (u.host.isBlank()) null else value } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 7 }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onBackPressed() { if (web != null) { web?.stopLoading(); showHome() } else super.onBackPressed() }

    private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
